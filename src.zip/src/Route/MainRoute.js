import React from 'react';
import { render } from 'react-dom';
import { BrowserRouter as Router, Route, Link, Redirect } from 'react-router-dom';
import LoginPage from '../loginPage/LoginPage'
import AdminDashboard from '../Admin/AdminDashboard';
import UserDashboard from '../User/UserDashboard';
import CarePlan from '../User/CarePlan/CarePlan'
import ActivityBoard from '../User/ActivityBoard/ActivityBoard'
import CareFamily from '../User/CareFamily/CareFamily'
import Messenger from '../User/Messenger/Messenger'


const MainRoute = () => (
  <Router>
    <div>
      {/* <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/about">About</Link></li>
        <li><Link to="/topics">Topics</Link></li>
      </ul> */}

      <Route exact path="/" component={LoginPage} />
      <Route path="/login" component={LoginPage} />
      {/* <Redirect from="/login" to="/login" /> */}
      <Route path="/home" component={UserDashboard} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/home/carefamily" component={CareFamily} />
      <Route path="/home/careplan" component={CarePlan} />
      <Route path="/home/activityboard" component={ActivityBoard} />
      <Route path="/home/messenger" component={Messenger} />
    </div>
  </Router>
);
export default MainRoute;

