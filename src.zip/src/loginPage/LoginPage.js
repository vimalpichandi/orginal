import React from 'react';
import { Link } from 'react-router-dom';
import { logo } from '../assets/img/logo.png';
import './login.css'
import { Redirect } from 'react-router';

class LoginPage extends React.Component {


    constructor(props) {
        super(props);
        this.state = { value: '' };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
        this.setState({ value: event.target.value });
    }

    handleSubmit(event) {
        // alert('A name was submitted: ' + this.state.value);

        // if (this.state.redirect) {
        //     return <Redirect push to="/admin" />;
        //   }
        if (this.state.value == "admin") {
            // alert("admin")
            this.props.history.push('/admin')
        } else if(this.state.value == "user") {
            // alert("sssssss")
            this.props.history.push('/home/careplan')
        }
        event.preventDefault();
    }


    render() {
        
        // const { loggingIn } = this.props;
        // const { username, password, submitted } = this.state;
        return (

            <div className="container-fluid no-padding h-100">
                <div className="row flex-row h-100 bg-white">
                    {/* Begin Left Content */}
                    <div className="col-xl-3 col-lg-5 col-md-5 col-sm-12 col-12 no-padding">
                        <div className="elisyam-bg background-03">
                            <div className="elisyam-overlay overlay-08" />
                            <div className="authentication-col-content-2 mx-auto text-center">
                                <div className="logo-centered">
                                    {/* <a href="db-default.html"> */}
                                    <img src={require('../assets/img/logo.png')} alt="logo" />
                                    {/* </a> */}
                                </div>
                                <h1>Welcome To RippleCARE</h1>
                                <span className="description">
                                    Begin your care journey Now
          </span>
                                {/*   <ul class="login-nav nav nav-tabs mt-5 justify-content-center" role="tablist" id="animate-tab">
                          <li><a class="active" data-toggle="tab" href="#singin" role="tab" id="singin-tab" data-easein="zoomInUp">Support</a></li>
                          <li><a data-toggle="tab" href="#signup" role="tab" id="signup-tab" data-easein="zoomInRight">FAQ</a></li>
                      </ul> */}
                            </div>
                        </div>
                    </div>
                    {/* End Left Content */}
                    {/* Begin Right Content */}
                    <div className="col-xl-9 col-lg-7 col-md-7 col-sm-12 col-12 my-auto no-padding">
                        {/* Begin Form */}
                        <div className="authentication-form-2 mx-auto">
                            <div className="tab-content" id="animate-tab-content">
                                {/* Begin Sign In */}
                                <div role="tabpanel" className="tab-pane show active" id="singin" aria-labelledby="singin-tab">
                                    <h3>Sign In</h3>
                                    <form onSubmit={this.handleSubmit}>
                                        <div className="group material-input">
                                            <input type="text" required value={this.state.username} onChange={this.handleChange} />
                                            <span className="highlight" />
                                            <span className="bar" />
                                            <label>Email</label>
                                        </div>
                                        <div className="group material-input">
                                            <input type="password" required value={this.state.password} onChange={this.handleChange} />
                                            <span className="highlight" />
                                            <span className="bar" />
                                            <label>Password</label>
                                        </div>
                                        <div className="space"></div>
                                        <div className="sign-btn text-center">
                                                <input  className="btn btn-lg btn-gradient-01" type="submit" value="Sign In" /> 

                                        </div>
                                        <div className="space"></div>

                                    </form>
                                    <div className="row">
                                        <div className="col text-left">
                                            <div className="styled-checkbox">
                                                <input type="checkbox" name="checkbox" id="remeber" />
                                                <label htmlFor="remeber">Remember me</label>
                                            </div>
                                        </div>
                                        <div className="col text-right">
                                            <a >Forgot Password ?</a>
                                        </div>
                                    </div>

                                </div>
                                {/* End Sign In */}
                                {/* Begin Sign Up */}
                                <div role="tabpanel" className="tab-pane" id="signup" aria-labelledby="signup-tab">
                                    <h3>Create An Account</h3>
                                    <form>
                                        <div className="group material-input">
                                            <input type="text" required />
                                            <span className="highlight" />
                                            <span className="bar" />
                                            <label>Email</label>
                                        </div>
                                        <div className="group material-input">
                                            <input type="password" required />
                                            <span className="highlight" />
                                            <span className="bar" />
                                            <label>Password</label>
                                        </div>
                                        <div className="group material-input">
                                            <input type="password" required />
                                            <span className="highlight" />
                                            <span className="bar" />
                                            <label>Confirm Password</label>
                                        </div>
                                    </form>
                                    <div className="row">
                                        <div className="col text-left">
                                            <div className="styled-checkbox">
                                                <input type="checkbox" name="checkbox" id="agree" />
                                                <label htmlFor="agree">I Accept <a href="#">Terms and Conditions</a></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="sign-btn text-center">
                                        <a className="btn btn-lg btn-gradient-01">
                                            Sign Up
              </a>
                                    </div>
                                </div>
                                {/* End Sign Up */}
                            </div>
                        </div>
                        {/* End Form */}
                    </div>
                    {/* End Right Content */}
                </div>
                {/* End Row */}
            </div>

        );
    }
}

export default LoginPage; 