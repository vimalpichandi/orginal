import React from 'react';
import logo from './logo.svg';
import './App.css';
import LoginPage from './loginPage/LoginPage'
import MainRoute from './Route/MainRoute'
function App() {
  return (
    <div className="App">
     <MainRoute />
    </div>
  );
}

export default App;
