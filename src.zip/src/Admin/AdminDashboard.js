import React from 'react';
import AdminHeader from '../Layout/Header/AdminHeader';
import Footer from '../Layout/Footer';
import AddClient from './AddClient/AddClient'
class AdminDashboard extends React.Component {

    render() {

        return (
            <div>
                <AdminHeader />
                <div className="content-inner compact active">
                    <AddClient />
                    <Footer />
                </div>
              
            </div>
        );
    }
}


export default AdminDashboard;