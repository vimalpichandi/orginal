import React from 'react';

class AdminDashboard extends React.Component {

    render() {

        return (
            <div className="container-fluid newsfeed">
                <div className="row justify-content-center">
                    {/* <div class="page-header">
          <div class="d-flex align-items-center">
              <h2 class="page-header-title">Dashboard</h2> 
             <div>
              
              </div> 
          </div>
      </div> */}
                    <div className="col-xl-12">
                        <div className="widget has-shadow">
                            <div className="widget-header bordered no-actions d-flex align-items-center">
                                {/*  <h2>Client List</h2> */}
                                <h2> <div className="page-header-tools">
                                    <button type="button" className="btn btn-danger" data-toggle="modal" data-target="#modal-large">Add New Client</button>
                                </div></h2>
                                {/* Clasify begins fc-state-active */}
                                <div className="fc fc-unthemed fc-ltr">
                                    <div className="fc-center">
                                        <div className="fc-button-group">
                                            <button type="button" className="fc-month-button fc-button fc-state-default fc-corner-left ">All</button>
                                            <button type="button" className="fc-agendaWeek-button fc-button fc-state-default">By Hospital</button>
                                            <button type="button" className="fc-agendaDay-button fc-button fc-state-default fc-corner-right">By Practice</button>
                                        </div>
                                    </div>
                                </div>
                                {/* Filter begins */}
                                <div className="widget-options ml-5">
                                    <div className="dropdown show">
                                        <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true" className="dropdown-toggle">
                                            <i className="la la-filter" />
                                        </button>
                                        <div className="dropdown-menu show" style={{ display: 'none', position: 'absolute', transform: 'translate3d(-92px, 36px, 0px)', top: 0, left: 0, willChange: 'transform' }} x-placement="bottom-start">
                                            <a href="#" className="dropdown-item">
                                                All
                </a>
                                            <a href="app-calendar.html" className="dropdown-item">
                                                Completed
                </a>
                                            <a href="app-calendar-list.html" className="dropdown-item">
                                                Pending
                </a>
                                            <a href="app-calendar-event.html" className="dropdown-item">
                                                In-Progress
                </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="widget-body">
                                <div className="table-responsive">
                                    <table className="table table-hover mb-0">
                                        <thead>
                                            <tr>
                                                <th>HSP/Practice Logo</th>
                                                <th>HSP/Practice Name</th>
                                                <th>CC</th>
                                                <th>Client Created Date</th>
                                                <th>Client Submitted Date</th>
                                                <th><span style={{ width: 100 }}>Status</span></th>
                                                <th>Onboarding Completed Date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><span className="text-primary">
                                                    <div className="media-left align-self-center pr-4">
                                                        <img src="abc.png" alt="..." className="user-img" />
                                                    </div>
                                                </span></td>
                                                <td>ABC Hospital</td>
                                                <td>Tina Williams</td>
                                                <td>04/08/2019</td>
                                                <td>04/08/2019</td>
                                                <td><span style={{ width: 100 }}><span className="badge-text badge-text-small success">Completed</span></span></td>
                                                <td>04/10/2019</td>
                                                <td className="td-actions">
                                                    <a href="#"><i className="la la-edit edit" /></a>
                                                    <a href="#"><i className="la la-close delete" /></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><span className="text-primary">
                                                    <div className="media-left align-self-center pr-4">
                                                        <img src="xy.jpg" alt="..." className="user-img" />
                                                    </div>
                                                </span></td>
                                                <td>Valencia</td>
                                                <td>Audrey Smith</td>
                                                <td>04/08/2019</td>
                                                <td>-</td>
                                                <td><span style={{ width: 100 }}><span className="badge-text badge-text-small danger">Pending</span></span></td>
                                                <td>-</td>
                                                <td className="td-actions">
                                                    <a href="#"><i className="la la-bell animated infinite swing" /></a>
                                                    <a href="#"><i className="la la-edit edit" /></a>
                                                    <a href="#"><i className="la la-close delete" /></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><span className="text-primary">
                                                    <div className="media-left align-self-center pr-4">
                                                        <img src="placeholder.jpg" alt="..." className="user-img" />
                                                    </div>
                                                </span></td>
                                                <td>Valencia</td>
                                                <td>Audrey Smith</td>
                                                <td>04/08/2019</td>
                                                <td>04/08/2019</td>
                                                <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">In-Progress</span></span></td>
                                                <td>-</td>
                                                <td className="td-actions">
                                                    <a href="#"><i className="la la-edit edit" /></a>
                                                    <a href="#"><i className="la la-close delete" /></a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* End Col */}
                </div>
                {/* End Row */}
                <div id="modal-large" className="modal fade">
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h4 className="modal-title">Add New Client</h4>
                                <button type="button" className="close" data-dismiss="modal">
                                    <span aria-hidden="true">×</span>
                                    <span className="sr-only">close</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div id="rootwizard">
                                    <div className="step-container">
                                        <div className="step-wizard">
                                            <div className="progress">
                                                <div className="progressbar" style={{ width: '100%' }} />
                                            </div>
                                            <ul className="nav nav-pills">
                                                <li>
                                                    <a href="#tab1" data-toggle="tab" className="active show">
                                                        <span className="step">1</span>
                                                        <span className="title">Step 1</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#tab2" data-toggle="tab" >
                                                        <span className="step">2</span>
                                                        <span className="title">Step 2</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#tab3" data-toggle="tab" >
                                                        <span className="step">3</span>
                                                        <span className="title">Step 3</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="tab-content">
                                        <div className="tab-pane active show" id="tab1">
                                            <div className="section-title mt-5 mb-5">
                                                <h4>Client Informations</h4>
                                            </div>
                                            <div className="form-group row mb-3">
                                                <div className="col-xl-8 mb-3">
                                                    <label className="form-control-label">Client Name<span className="text-danger ml-2">*</span></label>
                                                    <input defaultValue="Client Name" className="form-control" type="text" />
                                                </div>
                                                <div className="col-xl-4">
                                                    <label className="form-control-label">Select<span className="text-danger ml-2">*</span></label>
                                                    <div className="styled-radio">
                                                        <input name="radio" id="rad-1" type="radio" />
                                                        <label htmlFor="rad-1">Hospital</label>
                                                    </div>
                                                    <div className="styled-radio">
                                                        <input name="radio" id="rad-2" type="radio" />
                                                        <label htmlFor="rad-2">Practice</label></div>
                                                </div>
                                            </div>
                                            <div className="form-group row mb-5">
                                                <div className="col-xl-6 mb-3">
                                                    <label className="form-control-label">CMS UID </label>
                                                    <div className="input-group">
                                                        {/* <span class="input-group-addon addon-secondary">
                                                                  <i class="la la-phone"></i>
                                                              </span> */}
                                                        <input className="form-control" defaultValue="CMS UID " type="text" />
                                                    </div>
                                                </div>
                                                <div className="col-xl-6">
                                                    <label className="form-control-label">Medicare ID </label>
                                                    <input defaultValue="Medicare ID" className="form-control" type="text" />
                                                </div>
                                            </div>
                                            <div className="section-title mt-5 mb-5">
                                                <h4>For Reference: Enable/Disable based on logic Items</h4>
                                            </div>
                                            <div className="form-group row mb-3">
                                                <div className="col-xl-4 mb-3">
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-2" defaultChecked type="checkbox" />
                                                        <label htmlFor="check-2">BPCI-A </label>
                                                    </div>
                                                </div>
                                                <div className="mb-3">
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                        <label htmlFor="check-1">Mako</label>
                                                    </div>
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                        <label htmlFor="check-1">Mako - Outpatient</label>
                                                    </div>
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                        <label htmlFor="check-1">CJR</label>
                                                    </div>
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                        <label htmlFor="check-1">BPCI-A</label>
                                                    </div>
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                        <label htmlFor="check-1">BCPI-A – Outpatient</label>
                                                    </div>
                                                    <div className="styled-checkbox">
                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                        <label htmlFor="check-1">Mako</label>
                                                    </div>
                                                </div>
                                            </div>
                                            {/* <ul class="pager wizard text-right">
                                                                                          <li class="previous d-inline-block">
                                                                                              <a href="javascript:;" class="btn btn-secondary ripple">Previous</a>
                                                                                          </li>
                                                                                          <li class="next d-inline-block disabled">
                                                                                              <a href="javascript:;" class="btn btn-gradient-01">Next</a>
                                                                                          </li>
                                                                                      </ul>
                                                                                      */}                                                  </div>
                                        <div className="tab-pane" id="tab2">
                                            <div className="section-title mt-5 mb-5">
                                                <h4>Client Contact Information</h4>
                                            </div>
                                            <div className="form-group row mb-3">
                                                <div className="col-xl-6 mb-3">
                                                    <label className="form-control-label">First Name<span className="text-danger ml-2">*</span></label>
                                                    <input defaultValue="FN" className="form-control" type="text" />
                                                </div>
                                                <div className="col-xl-6">
                                                    <label className="form-control-label">Last Name<span className="text-danger ml-2">*</span></label>
                                                    <input defaultValue="LN" className="form-control" type="text" />
                                                </div>
                                            </div>
                                            <div className="form-group row mb-5">
                                                <div className="col-xl-6 mb-3">
                                                    <label className="form-control-label">Phone</label>
                                                    <div className="input-group">
                                                        {/* <span class="input-group-addon addon-secondary">
                                                                                                              <i class="la la-phone"></i>
                                                                                                          </span> */}
                                                        <input className="form-control" defaultValue="+00 987 654 32" type="text" />
                                                    </div>
                                                </div>
                                                <div className="col-xl-6">
                                                    <label className="form-control-label">Email</label>
                                                    <input defaultValue="Email" className="form-control" type="text" />
                                                </div>
                                            </div>
                                            {/* <div class="section-title mt-5 mb-5">
                                                                                                          <h4>Billing Information</h4>
                                                                                                      </div> */}
                                            {/*   <div class="form-group row mb-3">
                                                                                                          <div class="col-xl-12 mb-3">
                                                                                                              <label class="form-control-label">Card Number</label>
                                                                                                              <input value="98765432145698547" class="form-control" type="text">
                                                          </div>
                                                                                                          </div> */}
                                            {/* <div class="form-group row mb-3">
                                                                                                              <div class="col-xl-4 mb-3">
                                                                                                                  <label class="form-control-label">Exp Month<span class="text-danger ml-2">*</span></label>
                                                                                                                  <select name="exp-month" class="custom-select form-control">
                                                                                                                      <option value="">Select</option>
                                                                                                                      <option value="01">01</option>
                                                                                                                      <option value="02">02</option>
                                                                                                                      <option value="03">03</option>
                                                                                                                      <option value="04">04</option>
                                                                                                                      <option value="05">05</option>
                                                                                                                      <option value="06" selected="">06</option>
                                                                                                                      <option value="07">07</option>
                                                                                                                      <option value="08">08</option>
                                                                                                                      <option value="09">09</option>
                                                                                                                      <option value="10">10</option>
                                                                                                                      <option value="11">11</option>
                                                                                                                      <option value="12">12</option>
                                                                                                                  </select>
                                                                                                              </div>
                                                                                                              <div class="col-xl-4 mb-3">
                                                                                                                  <label class="form-control-label">Exp Year<span class="text-danger ml-2">*</span></label>
                                                                                                                  <select name="exp-month" class="custom-select form-control">
                                                                                                                      <option value="2018">2018</option>
                                                                                                                      <option value="2019">2019</option>
                                                                                                                      <option value="2020">2020</option>
                                                                                                                      <option value="2021">2021</option>
                                                                                                                      <option value="2022">2022</option>
                                                                                                                      <option value="2023" selected="">2023</option>
                                                                                                                      <option value="2024">2024</option>
                                                                                                                  </select>
                                                                                                              </div>
                                                                                                              <div class="col-xl-4">
                                                                                                                  <label class="form-control-label">CVV<span class="text-danger ml-2">*</span></label>
                                                                                                                  <input value="651" class="form-control" type="email">
                                                          </div>
                                                                                                              </div> */}
                                            {/*  <div class="form-group row mb-3">
                                                                                                                  <div class="col-xl-12">
                                                                                                                      <div class="styled-checkbox">
                                                                                                                          <input name="savecard" id="check-card" type="checkbox">
                                                                                                                              <label for="check-card">Save this card</label>
                                                              </div>
                                                                                                                      </div>
                                                                                                                  </div> */}
                                            {/*  <ul class="pager wizard text-right">
                                                                                                                      <li class="previous d-inline-block">
                                                                                                                          <a href="javascript:;" class="btn btn-secondary ripple">Previous</a>
                                                                                                                      </li>
                                                                                                                      <li class="next d-inline-block disabled">
                                                                                                                          <a href="javascript:;" class="btn btn-gradient-01">Next</a>
                                                                                                                      </li>
                                                                                                                  </ul> */}
                                        </div>
                                        <div className="tab-pane" id="tab3">
                                            <div className="section-title mt-5 mb-5">
                                                <h4>Service Lines</h4>
                                            </div>
                                            {/*  <div id="accordion-icon-right" class="accordion">
                                                                                                                      <div class="widget has-shadow">
                                                                                                                          <a class="card-header collapsed d-flex align-items-center" data-toggle="collapse" href="#IconRightCollapseOne" aria-expanded="true">
                                                                                                                              <div class="card-title w-100">1. Client Informations</div>
                                                                                                                          </a>
                                                                                                                          <div id="IconRightCollapseOne" class="card-body collapse show" data-parent="#accordion-icon-right">
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Name</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">David Green</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Email</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">dgreen@example.com</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Phone</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">+00 987 654 32</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Occupation</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">UX Designer</div>
                                                                                                                              </div>
                                                                                                                          </div>
                                                                                                                          <a class="card-header collapsed d-flex align-items-center" data-toggle="collapse" href="#IconRightCollapseTwo">
                                                                                                                              <div class="card-title w-100">2. Address</div>
                                                                                                                          </a>
                                                                                                                          <div id="IconRightCollapseTwo" class="card-body collapse" data-parent="#accordion-icon-right">
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Address</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">123 Century Blvd</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Country</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">Country</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">City</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">Los Angeles</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">State</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">CA</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Zip</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">90045</div>
                                                                                                                              </div>
                                                                                                                          </div>
                                                                                                                          <a class="card-header collapsed d-flex align-items-center" data-toggle="collapse" href="#IconRightCollapseThree">
                                                                                                                              <div class="card-title w-100">3. Account Details</div>
                                                                                                                          </a>
                                                                                                                          <div id="IconRightCollapseThree" class="card-body collapse" data-parent="#accordion-icon-right">
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Username</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">Saerox</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Password</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext"><span class="la-2x">*********</span></div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Url</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">http://mywebsite.com</div>
                                                                                                                              </div>
                                                                                                                          </div>
                                                                                                                          <a class="card-header collapsed d-flex align-items-center" data-toggle="collapse" href="#IconRightCollapseFour">
                                                                                                                              <div class="card-title w-100">4. Billing Information</div>
                                                                                                                          </a>
                                                                                                                          <div id="IconRightCollapseFour" class="card-body collapse" data-parent="#accordion-icon-right">
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Card Number</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">98765432145698547</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Exp Month</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">06</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">Exp Year</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">2023</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-sm-3 form-control-label d-flex align-items-center">CVV</div>
                                                                                                                                  <div class="col-sm-8 form-control-plaintext">651</div>
                                                                                                                              </div>
                                                                                                                              <div class="form-group row mb-5">
                                                                                                                                  <div class="col-xl-12">
                                                                                                                                      <div class="styled-checkbox">
                                                                                                                                          <input name="checkbox" id="agree" type="checkbox">
                                                                                                                                              <label for="agree">I Accept <a href="#">Terms and Conditions</a></label>
                                                                          </div>
                                                                                                                                      </div>
                                                                                                                                  </div>
                                                                                                                              </div>
                                                                                                                          </div>
                                                                                                                      </div> */}
                                            {/* <ul class="pager wizard text-right">
                                                                                                                          <li class="previous d-inline-block">
                                                                                                                              <a href="javascript:void(0)" class="btn btn-secondary ripple">Previous</a>
                                                                                                                          </li>
                                                                                                                          <li class="next d-inline-block disabled">
                                                                                                                              <a href="javascript:void(0)" class="finish btn btn-gradient-01" data-toggle="modal">Finish</a>
                                                                                                                          </li>
                                                                                                                      </ul> */}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-shadow" data-dismiss="modal">Close</button>
                                <button type="button" className="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        );
    }
}


export default AdminDashboard;