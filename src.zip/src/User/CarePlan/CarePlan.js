import React from 'react';
import Footer from '../../Layout/Footer'


class CarePlan extends React.Component {
    // componentDidMount() {
    //     this.props.dispatch(userActions.getAll());
    // }

    render() {
        const page_h_name = {
            fontsize: ' 1rem',
            padding: '5px',
            display: 'block'
        }
        return (
            < div className="content-inner compact" >
                <div className="container-fluid newsfeed">
                    <div className="row justify-content-center">
                        <div className="page-header">
                            <div className="d-flex align-items-center">
                                <h2 className="page-header-title">Welcome, Anna Jones
                                <span style={{ padding: 5, display: 'block', fontSize: '1rem' }}>
                                        ABC Hospital
                                    </span></h2>
                                <div>
                                    <div className="page-header-tools">
                                        <button type="button" className="btn btn-danger" data-toggle="modal" data-target="#modal-large">View Audit History</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-xl-12">
                            <div className="widget has-shadow">
                                <div className="widget-body sliding-tabs">
                                    <ul className="nav nav-tabs" id="example-one" role="tablist">
                                        <li className="nav-item">
                                            <a className="nav-link active show" id="base-tab-1" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true" style={{ fontSize: '1.2rem' }}><i className="ion-home mr-2" style={{ fontSize: '1.5rem' }} />Home</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" id="base-tab-2" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false" style={{ fontSize: '1.2rem' }}><i className="ion-person-stalker mr-2" style={{ fontSize: '1.5rem' }} />Care Family</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" id="base-tab-3" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false" style={{ fontSize: '1.2rem' }}><i className="ion-briefcase mr-2" style={{ fontSize: '1.5rem' }} />PAC</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" id="base-tab-4" data-toggle="tab" href="#tab-4" role="tab" aria-controls="tab-4" aria-selected="false" style={{ fontSize: '1.2rem' }}><i className="ion-clipboard mr-2" style={{ fontSize: '1.5rem' }} />My To-Do's</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" id="base-tab-5" data-toggle="tab" href="#tab-5" role="tab" aria-controls="tab-5" aria-selected="false" style={{ fontSize: '1.2rem' }}><i className="ion-social-buffer-outline mr-2" style={{ fontSize: '1.5rem' }} />Activities</a>
                                        </li>
                                    </ul>
                                    {/*tab begin div below */}
                                    <div className="tab-content pt-3">
                                        <div className="tab-pane fade active show" id="tab-1" role="tabpanel" aria-labelledby="base-tab-1">
                                            {/* Inside portionsmain div below */}
                                            <div className="row flex-row mt-3">
                                                <div className="col-xl-3 col-md-6">
                                                    {/* Begin Widget 08 */}
                                                    <div className="widget widget-08 has-shadow">
                                                        {/* Begin Widget Header */}
                                                        <div className="widget-header bordered d-flex align-items-center">
                                                            <h4>Your Info</h4>
                                                        </div>
                                                        {/* End Widget Header */}
                                                        {/* Begin Widget Body */}
                                                        <div className="widget-body">
                                                            {/* Begin List */}
                                                            <div className="todo-list">
                                                                <ul id="sortable" className="list">
                                                                    <li className="task-color task-violet">
                                                                        <div className="styled-checkbox">
                                                                            <input id="task-1" type="checkbox" />
                                                                            <label className="text-primary" htmlFor="task-1">Add Logo</label>
                                                                        </div>
                                                                    </li>
                                                                    <li className="task-color task-blue">
                                                                        <div className="styled-checkbox">
                                                                            <input id="task-3" type="checkbox" />
                                                                            <label className="text-info" htmlFor="task-3">Add Login Background Image</label>
                                                                        </div>
                                                                    </li>
                                                                    <li>
                                                                        <div className="actions text-center">
                                                                            <a href="#" className="btn btn-gradient-01">Preview</a>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                            {/* End List */}
                                                        </div>
                                                        {/* End Widget Body */}
                                                    </div>
                                                    {/* End Widget 08 */}
                                                </div>
                                                <div className="col-xl-5 col-md-6">
                                                    {/* Begin Widget 10 */}
                                                    <div className="widget widget-11 has-shadow">
                                                        {/* Begin Widget Header */}
                                                        <div className="widget-header bordered d-flex align-items-center">
                                                            <h4>Care Family Summary</h4>
                                                        </div>
                                                        {/* End Widget Header */}
                                                        {/* Begin Widget Body */}
                                                        <div className="widget-body p-0 widget-scroll" style={{ maxHeight: 450, overflow: 'hidden' }} tabIndex={3}>
                                                            {/* Begin 01 */}
                                                            {/* End 01 */}
                                                            {/* Begin 02 */}
                                                            {/* End 02 */}
                                                            {/* Begin 03 */}
                                                            <div className="timeline violet">
                                                                <div className="timeline-content d-flex align-items-center">
                                                                    {/*   <div class="user-image">
                                      <img class="rounded-circle" src="assets/img/avatar/avatar-05.jpg" alt="...">
                                  </div> */}
                                                                    <div className="d-flex flex-column mr-auto">
                                                                        <div className="title">
                                                                            <span className="username">4</span>
                                                                            Surgeon in your hsp/practice
                                                                            <div className="users-like">
                                                                                <a >
                                                                                    <img src={require('../../assets/img/avatar/avatar-01.jpg')} className="img-fluid rounded-circle" alt="..." />
                                                                                </a>
                                                                                <a >
                                                                                    <img src={require('../../assets/img/avatar/avatar-02.jpg')} className="img-fluid rounded-circle" alt="..." />
                                                                                </a>
                                                                                <a >
                                                                                    <img src={require('../../assets/img/avatar/avatar-07.jpg')} className="img-fluid rounded-circle" alt="..." />
                                                                                </a>
                                                                                <a >
                                                                                    <img src={require('../../assets/img/avatar/avatar-09.jpg')} className="img-fluid rounded-circle" alt="..." />
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <div className="time" data-toggle="tooltip" data-placement="bottom" title="Tooltip on bottom">Added 15 min ago</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            {/* End 03 */}
                                                            {/* Begin 06 */}
                                                            <div className="timeline blue">
                                                                <div className="timeline-content d-flex align-items-center">
                                                                    {/*   <div class="user-image">
                                      <img class="rounded-circle" src="assets/img/avatar/avatar-05.jpg" alt="...">
                                  </div> */}
                                                                    <div className="d-flex flex-column mr-auto">
                                                                        <div className="title">
                                                                            <span className="username">2</span>
                                                                            Care Navigators
                                                                            <div className="users-like">
                                                                                <a >
                                                                                    <img src={require('../../assets/img/avatar/avatar-01.jpg')} className="img-fluid rounded-circle" alt="..." />
                                                                                </a>
                                                                                <a >
                                                                                    <img src={require('../../assets/img/avatar/avatar-02.jpg')} className="img-fluid rounded-circle" alt="..." />
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                        <div className="time">Added 12 min ago</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            {/* End 06 */}
                                                            {/* Begin 06 */}
                                                            {/* End 06 */}
                                                            {/* Begin 07 */}
                                                            <div className="actions">
                                                                <a href="#" className="btn btn-gradient-03">Add New</a>
                                                            </div>
                                                            {/* End 07 */}
                                                        </div>
                                                        {/* End Widget Body */}
                                                    </div>
                                                    {/* End Widget 10 */}
                                                </div>
                                                <div className="col-xl-4">
                                                    {/* Begin Widget 11 */}
                                                    <div className="widget widget-11 has-shadow">
                                                        {/* Begin Widget Header */}
                                                        <div className="widget-header bordered d-flex align-items-center">
                                                            <h4>PAC Facilities</h4>
                                                        </div>
                                                        {/* End Widget Header */}
                                                        {/* Begin Widget Body */}
                                                        <div className="widget-body p-0 widget-scroll" style={{ maxHeight: 450, overflow: 'hidden' }} tabIndex={3}>
                                                            {/* Begin 07 */}
                                                            <div className="timeline red">
                                                                <div className="timeline-content d-flex align-items-center">
                                                                    <div className="timeline-icon">
                                                                        <i className="la la-image" />
                                                                    </div>
                                                                    <div className="d-flex flex-column mr-auto">
                                                                        <div className="title">
                                                                            <span className="username">2</span>
                                                                            SNF <span className="font-weight-bold"><a href="#">Facilities</a></span>
                                                                        </div>
                                                                        <div className="time">Added 1 hour ago</div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            {/* End 07 */}
                                                        </div>
                                                        {/* End Widget Body */}
                                                    </div>
                                                    {/* End Widget 11 */}
                                                </div>
                                            </div>
                                            {/*tab end div below */}
                                        </div>
                                        <div className="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="base-tab-2">
                                            <div className="row flex-row">
                                                <div className="col-xl-2">
                                                    {/* Begin Widget */}
                                                    <div className="widget has-shadow">
                                                        <div className="widget-body">
                                                            <ul className="nav flex-column" role="tablist" aria-orientation="vertical">
                                                                <li className="nav-item">
                                                                    <a className="nav-link active" id="vert-tab-1" data-toggle="tab" href="#v-tab-1" role="tab" aria-controls="v-tab-1" aria-selected="true">Surgeon</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-2" data-toggle="tab" href="#v-tab-2" role="tab" aria-controls="v-tab-2" aria-selected="false">Care Navigator</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-3" data-toggle="tab" href="#v-tab-3" role="tab" aria-controls="v-tab-3" aria-selected="false">Admin</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-4" data-toggle="tab" href="#v-tab-4" role="tab" aria-controls="v-tab-4" aria-selected="false">Additional</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-5" data-toggle="tab" href="#v-tab-5" role="tab" aria-controls="v-tab-5" aria-selected="false">Groups</a><hr />
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    {/* End Widget */}
                                                </div>
                                                <div className="col-xl-10">
                                                    <div className="widget has-shadow">
                                                        {/*   <div class="widget-header bordered no-actions d-flex align-items-center">
                             
                              
                          </div> */}
                                                        <style type="text/css" dangerouslySetInnerHTML={{ __html: "\n.fade:not(.show) {\n\ndisplay: none !important;\n}\n" }} />
                                                        <div className="widget-body">
                                                            <div className="table-responsive">
                                                                <div id="sorting-table_wrapper" className="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                                                    <div className="row"><div className="col-sm-12 col-md-6">
                                                                        <button type="button" className="btn btn-gradient-03 mr-1 mb-2">Add New</button>
                                                                        {/*  <div class="dataTables_length" id="sorting-table_length">
                                              <label>Show <select name="sorting-table_length" aria-controls="sorting-table" class="form-control form-control-sm">
                                                  <option value="10">10</option>
                                                  <option value="15">15</option>
                                                  <option value="20">20</option>
                                                  <option value="-1">All</option>
                                              </select> entries</label>
                                          </div> */}
                                                                    </div>
                                                                        <div className="col-sm-12 col-md-6 pull-right">
                                                                            <div id="sorting-table_filter" className="dataTables_filter">
                                                                                <label>Search:
                                    <input className="form-control form-control-sm" placeholder aria-controls="sorting-table" type="search" />
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="row">
                                                                        <div className="col-sm-12">
                                                                            <div className="tab-pane fade show active" id="v-tab-1" role="tabpanel" aria-labelledby="vert-tab-1">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Pic</th>
                                                                                            <th>First Name</th>
                                                                                            <th>Last Name</th>
                                                                                            <th>Credentials</th>
                                                                                            <th>NPI #</th>
                                                                                            <th><span style={{ width: 100 }}>Bio</span></th>
                                                                                            <th>Specialty</th>
                                                                                            <th>Procedure Performed</th>
                                                                                            <th>Site of Service</th>
                                                                                            <th>Access for Portal</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">MD or DO</td>
                                                                                            <td className="sorting_1">1232455</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>Orthopaedic</td>
                                                                                            <td>Surgery</td>
                                                                                            <td>ABC Hospital</td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">MD or DO</td>
                                                                                            <td className="sorting_1">1232455</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>Orthopaedic</td>
                                                                                            <td>Surgery</td>
                                                                                            <td>ABC Hospital</td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="optionss" id="opt-02" required type="radio" />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-02">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-2" role="tabpanel" aria-labelledby="vert-tab-2">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Pic</th>
                                                                                            <th>First Name</th>
                                                                                            <th>Last Name</th>
                                                                                            <th>Email ID</th>
                                                                                            <th>Title</th>
                                                                                            <th>Role</th>
                                                                                            <th><span style={{ width: 100 }}>Bio</span></th>
                                                                                            <th>Access for Portal</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-3" role="tabpanel" aria-labelledby="vert-tab-3">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Pic</th>
                                                                                            <th>First Name</th>
                                                                                            <th>Last Name</th>
                                                                                            <th>Email ID</th>
                                                                                            <th>Title</th>
                                                                                            <th>Role</th>
                                                                                            <th><span style={{ width: 100 }}>Bio</span></th>
                                                                                            <th>Access for Portal</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-4" role="tabpanel" aria-labelledby="vert-tab-4">
                                                                                <table id="sorting-table as" className="table mb-0 dataTable no-footer">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Pic</th>
                                                                                            <th>First Name</th>
                                                                                            <th>Last Name</th>
                                                                                            <th>Email ID</th>
                                                                                            <th>Title</th>
                                                                                            <th>Role</th>
                                                                                            <th><span style={{ width: 100 }}>Bio</span></th>
                                                                                            <th>Access for Portal</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-5" role="tabpanel" aria-labelledby="vert-tab-5">
                                                                                <table id="sorting-table as" className="table mb-0 dataTable no-footer">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Pic</th>
                                                                                            <th>First Name</th>
                                                                                            <th>Last Name</th>
                                                                                            <th>Email ID</th>
                                                                                            <th>Title</th>
                                                                                            <th>Role</th>
                                                                                            <th><span style={{ width: 100 }}>Bio</span></th>
                                                                                            <th>Access for Portal</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td><span className="text-primary"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." style={{ width: 50 }} className="avatar rounded-circle d-block mx-auto" /></span></td>
                                                                                            <td>Lori </td>
                                                                                            <td>Baker</td>
                                                                                            <td className="sorting_1">Lori@abc.com</td>
                                                                                            <td className="sorting_1">Mr/Ms</td>
                                                                                            <td className="sorting_1">CN</td>
                                                                                            <td><span style={{ width: 100 }}><span className="badge-text badge-text-small info">View</span></span></td>
                                                                                            <td>
                                                                                                <div className="mb-3 form-group">
                                                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                                                        <input className="custom-control-input" name="options" id="opt-01" required type="radio" defaultChecked />
                                                                                                        <label className="custom-control-descfeedback" htmlFor="opt-01">No Access</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-1" type="checkbox" />
                                                                                                        <label htmlFor="check-1">HRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-2" type="checkbox" />
                                                                                                        <label htmlFor="check-2">PRO</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-3" type="checkbox" />
                                                                                                        <label htmlFor="check-3">RC</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-4" type="checkbox" />
                                                                                                        <label htmlFor="check-4">EPM</label>
                                                                                                    </div>
                                                                                                    <div className="styled-checkbox">
                                                                                                        <input name="checkbox" id="check-5" type="checkbox" />
                                                                                                        <label htmlFor="check-5">RC Report</label>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </td>
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div></div>
                                                                </div>
                                                            </div>
                                                            {/*  
                              <div class="em-separator separator-dashed"></div>
                              <div class="text-right">
                                  <button class="btn btn-gradient-01" type="submit">Save Changes</button>
                                  <button class="btn btn-shadow" type="reset">Cancel</button>
                              </div> */}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="base-tab-3">
                                            <div className="row flex-row">
                                                <div className="col-xl-2">
                                                    {/* Begin Widget */}
                                                    <div className="widget has-shadow">
                                                        <div className="widget-body">
                                                            <ul className="nav flex-column" role="tablist" aria-orientation="vertical">
                                                                <li className="nav-item">
                                                                    <a className="nav-link active" id="vert-tab-6" data-toggle="tab" href="#v-tab-6" role="tab" aria-controls="v-tab-6" aria-selected="true">SNF</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-7" data-toggle="tab" href="#v-tab-7" role="tab" aria-controls="v-tab-7" aria-selected="false">Home Health</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-8" data-toggle="tab" href="#v-tab-8" role="tab" aria-controls="v-tab-8" aria-selected="false">Acute Rehab</a><hr />
                                                                </li>
                                                                <li className="nav-item">
                                                                    <a className="nav-link" id="vert-tab-9" data-toggle="tab" href="#v-tab-9" role="tab" aria-controls="v-tab-9" aria-selected="false">OPPT</a><hr />
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    {/* End Widget */}
                                                </div>
                                                <div className="col-xl-10">
                                                    <div className="widget has-shadow">
                                                        {/*   <div class="widget-header bordered no-actions d-flex align-items-center">
                             
                              
                          </div> */}
                                                        <div className="widget-body">
                                                            <div className="table-responsive">
                                                                <div id="sorting-table_wrapper" className="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
                                                                    <div className="row"><div className="col-sm-12 col-md-6">
                                                                        <button type="button" className="btn btn-gradient-03 mr-1 mb-2">Add New</button>
                                                                        {/*  <div class="dataTables_length" id="sorting-table_length">
                                              <label>Show <select name="sorting-table_length" aria-controls="sorting-table" class="form-control form-control-sm">
                                                  <option value="10">10</option>
                                                  <option value="15">15</option>
                                                  <option value="20">20</option>
                                                  <option value="-1">All</option>
                                              </select> entries</label>
                                          </div> */}
                                                                    </div>
                                                                        <div className="col-sm-12 col-md-6 pull-right">
                                                                            <div id="sorting-table_filter" className="dataTables_filter">
                                                                                <label>Search:
                                    <input className="form-control form-control-sm" placeholder aria-controls="sorting-table" type="search" />
                                                                                </label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="row">
                                                                        <div className="col-sm-12">
                                                                            <div className="tab-pane fade show active" id="v-tab-6" role="tabpanel" aria-labelledby="vert-tab-6">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer" role="grid" aria-describedby="sorting-table_info">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Facility Name</th>
                                                                                            <th>Facility Street</th>
                                                                                            <th>Facility City</th>
                                                                                            <th>Facility State</th>
                                                                                            <th>Facility Zip Code</th>
                                                                                            <th>Facility Contact Person</th>
                                                                                            <th>Facility Phone</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>ABC SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                              <td>Orthopaedic</td>
                                               <td>Surgery</td>
                                              <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>ABC SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                                                                                    <td>Orthopaedic</td>
                                                                                                    <td>Surgery</td>
                                                                                                    <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-7" role="tabpanel" aria-labelledby="vert-tab-7">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer" role="grid" aria-describedby="sorting-table_info">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Facility Name</th>
                                                                                            <th>Facility Street</th>
                                                                                            <th>Facility City</th>
                                                                                            <th>Facility State</th>
                                                                                            <th>Facility Zip Code</th>
                                                                                            <th>Facility Contact Person</th>
                                                                                            <th>Facility Phone</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>XYZ SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                                                                                    <td>Orthopaedic</td>
                                                                                                    <td>Surgery</td>
                                                                                                    <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>XYZ SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                              <td>Orthopaedic</td>
                                               <td>Surgery</td>
                                              <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-8" role="tabpanel" aria-labelledby="vert-tab-8">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer" role="grid" aria-describedby="sorting-table_info">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Facility Name</th>
                                                                                            <th>Facility Street</th>
                                                                                            <th>Facility City</th>
                                                                                            <th>Facility State</th>
                                                                                            <th>Facility Zip Code</th>
                                                                                            <th>Facility Contact Person</th>
                                                                                            <th>Facility Phone</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>PQR SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                              <td>Orthopaedic</td>
                                               <td>Surgery</td>
                                              <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>PQR SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                              <td>Orthopaedic</td>
                                               <td>Surgery</td>
                                              <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                            <div className="tab-pane fade" id="v-tab-9" role="tabpanel" aria-labelledby="vert-tab-9">
                                                                                <table id="sorting-table" className="table mb-0 dataTable no-footer" role="grid" aria-describedby="sorting-table_info">
                                                                                    <thead>
                                                                                        <tr role="row">
                                                                                            <th>Facility Name</th>
                                                                                            <th>Facility Street</th>
                                                                                            <th>Facility City</th>
                                                                                            <th>Facility State</th>
                                                                                            <th>Facility Zip Code</th>
                                                                                            <th>Facility Contact Person</th>
                                                                                            <th>Facility Phone</th>
                                                                                            <th>Actions</th></tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>GHI SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                              <td>Orthopaedic</td>
                                               <td>Surgery</td>
                                              <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                        <tr role="row" className="odd">
                                                                                            <td>GHI SNF </td>
                                                                                            <td>Walter Street</td>
                                                                                            <td>Illinois,</td>
                                                                                            <td>Bartlett,</td>
                                                                                            <td>601063</td>
                                                                                            <td className="sorting_1">Anna Mary Jones</td>
                                                                                            <td className="sorting_1">1234567890</td>
                                                                                            {/*    <td><span style="width:100px;"><span class="badge-text badge-text-small info">View</span></span></td>
                                              <td>Orthopaedic</td>
                                               <td>Surgery</td>
                                              <td>ABC Hospital</td> */}
                                                                                            <td className="td-actions">
                                                                                                {/*  <a href="#"><i class="la la-eye edit"></i></a> */}
                                                                                                <a href="#"><i className="la la-edit edit" /></a>
                                                                                                <a href="#"><i className="la la-close delete" /></a>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </tbody>
                                                                                </table>
                                                                            </div>
                                                                        </div></div>
                                                                </div>
                                                            </div>
                                                            {/*  
                              <div class="em-separator separator-dashed"></div>
                              <div class="text-right">
                                  <button class="btn btn-gradient-01" type="submit">Save Changes</button>
                                  <button class="btn btn-shadow" type="reset">Cancel</button>
                              </div> */}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="tab-pane fade active" id="tab-4" role="tabpanel" aria-labelledby="base-tab-4">
                                            <table id="sorting-table" className="table mb-0 dataTable no-footer" role="grid" aria-describedby="sorting-table_info">
                                                <thead>
                                                    <tr role="row">
                                                        <th>Generate Care Plan</th>
                                                        <th>Schedule Pre-Op Class (hospital)</th>
                                                        <th>Schedule Pre-Op Testing (hospital)</th>
                                                        <th>Follow-Up with Unprepared Patient</th>
                                                        <th>Track Hospital Discharge</th>
                                                        <th>Follow-Up with SNF </th>
                                                        <th>Follow-Up with PAC</th>
                                                        <th>View New Symptom</th>
                                                        <th>Recovery Behind Goal</th>
                                                        <th>Patient Phone Calls </th>
                                                        <th>Post-Op Complication</th>
                                                        {/*      <th>Actions</th> */}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr role="row" className="odd">
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options051" id="opt-051" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-051">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options051" id="opt-061" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-061">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options052" id="opt-052" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-052">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options052" id="opt-062" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-062">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options053" id="opt-053" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-053">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options053" id="opt-063" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-063">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options054" id="opt-054" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-054">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options054" id="opt-064" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-064">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options055" id="opt-055" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-055">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options055" id="opt-065" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-065">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options056" id="opt-056" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-056">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options056" id="opt-066" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-066">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options057" id="opt-057" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-057">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options057" id="opt-067" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-067">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options058" id="opt-058" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-058">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options058" id="opt-068" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-068">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options059" id="opt-059" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-059">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options059" id="opt-069" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-069">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options0511" id="opt-0511" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-0511">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options0511" id="opt-0611" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-0611">Off</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options0512" id="opt-0512" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-0512">On</label>
                                                            </div>
                                                            <div className="custom-control custom-radio styled-radio mb-3">
                                                                <input className="custom-control-input" name="options0512" id="opt-0612" required type="radio" />
                                                                <label className="custom-control-descfeedback" htmlFor="opt-0612">Off</label>
                                                            </div>
                                                        </td>
                                                        {/* 
                                                <td class="td-actions">
                                             
                                                  <a href="#"><i class="la la-edit edit"></i></a>
                                                  <a href="#"><i class="la la-close delete"></i></a>
                                              </td> */}
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div className="tab-pane fade active" id="tab-5" role="tabpanel" aria-labelledby="base-tab-5">
                                            <div className="widget-body">
                                                <div className="table-responsive">
                                                    <table id="sorting-table" className="table mb-0">
                                                        <thead>
                                                            <tr>
                                                                <th>Title</th>
                                                                <th>Assigned Date</th>
                                                                <th>Status</th>
                                                                <th>Procedure</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td><span className="text-primary">Day Of Surgery</span></td>
                                                                <td>Two days before surgery</td>
                                                                <td>
                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                        <input className="custom-control-input" name="options101" id="opt-101" required type="radio" defaultChecked />
                                                                        <label className="custom-control-descfeedback" htmlFor="opt-101">On</label>
                                                                    </div>
                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                        <input className="custom-control-input" name="options101" id="opt-102" required type="radio" defaultChecked />
                                                                        <label className="custom-control-descfeedback" htmlFor="opt-102">Off</label>
                                                                    </div>
                                                                    <div className="custom-control custom-radio styled-radio mb-3">
                                                                        <input className="custom-control-input" name="options103" id="opt-103" required type="radio" />
                                                                        <label className="custom-control-descfeedback" htmlFor="opt-103">Edit</label>
                                                                    </div>
                                                                </td>
                                                                <td>TKA, THA, ALL</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* <ul class="pull-right">
                                                      <li class="previous d-inline-block disabled">
                                                          <a href="#tab-3" aria-controls="tab-3"" class="btn btn-secondary ripple">Previous</a>
                                                      </li>
                                                      <li class="next d-inline-block">
                                                          <a href="#tab-2" aria-controls="tab-2" class="btn btn-gradient-01">Next</a>
                                                      </li>
                                                  </ul>
*/}
                        </div>
                        {/* End Col */}
                    </div>
                    {/* End Row */}
                </div>
                {/* End Container */}
                {/* Begin Large Modal */}
                <div id="modal-large" className="modal fade">
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h4 className="modal-title">Audit History</h4>
                                <button type="button" className="close" data-dismiss="modal">
                                    <span aria-hidden="true">×</span>
                                    <span className="sr-only">close</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="widget-body no-padding">
                                    <ul className="ticket list-group w-100">
                                        {/* 01 */}
                                        <li className="list-group-item">
                                            <div className="media">
                                                <div className="media-left align-self-center pr-4">
                                                    <img src={require('../../assets/img/avatar/avatar-02.jpg')} className="user-img rounded-circle" alt="..." />
                                                </div>
                                                <div className="media-body align-self-center">
                                                    <div className="username">
                                                        <h4>Brandon Smith</h4>
                                                    </div>
                                                    <div className="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                      </p>
                                                    </div>
                                                    <div className="status"><span className="open mr-2">Open</span>(1 hour ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* End 01 */}
                                        {/* 02 */}
                                        <li className="list-group-item">
                                            <div className="media">
                                                <div className="media-left align-self-center pr-4">
                                                    <img src={require('../../assets/img/avatar/avatar-04.jpg')} className="user-img rounded-circle" alt="..." />
                                                </div>
                                                <div className="media-body align-self-center">
                                                    <div className="username">
                                                        <h4>Nathan Hunter</h4>
                                                    </div>
                                                    <div className="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                      </p>
                                                    </div>
                                                    <div className="status"><span className="pending mr-2">Modified</span>(2 hours ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* End 02 */}
                                        {/* 03 */}
                                        <li className="list-group-item">
                                            <div className="media">
                                                <div className="media-left align-self-center pr-4">
                                                    <img src={require('../../assets/img/avatar/avatar-05.jpg')} className="user-img rounded-circle" alt="..." />
                                                </div>
                                                <div className="media-body align-self-center">
                                                    <div className="username">
                                                        <h4>Megan Duncan</h4>
                                                    </div>
                                                    <div className="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                      </p>
                                                    </div>
                                                    <div className="status"><span className="closed mr-2">Deleted</span>(1 day ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* End 03 */}
                                    </ul>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-shadow" data-dismiss="modal">Close</button>
                                <button type="button" className="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
                {/* End Large Modal */}

                <a href="#" className="go-top"><i className="la la-arrow-up" /></a>
                {/* Offcanvas Sidebar */}
                {/* End Offcanvas Sidebar */}
                <Footer />
            </div >


        );
    }
}


export default CarePlan;