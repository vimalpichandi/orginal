import React from 'react';
import Footer from '../../Layout/Footer'


class ActivityBoard extends React.Component {
    // componentDidMount() {
    //     this.props.dispatch(userActions.getAll());
    // }

    render() {

        return (
            < div className="content-inner compact" >
                <div className="container-fluid newsfeed">
                    <div className="row justify-content-center">
                        <div className="page-header">
                            <div className="d-flex align-items-center">
                                <h2 className="page-header-title">Welcome, Anna Jones
                                <span style={{ padding: 5, display: 'block', fontSize: '1rem' }}>
                                        ABC Hospital
                                    </span></h2>
                                <div>
                                    <div className="page-header-tools">
                                        <button type="button" className="btn btn-danger" data-toggle="modal" data-target="#modal-large">View Audit History</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-xl-12">
                            <div className="widget has-shadow">
                                <div classname="widget-body sliding-tabs" style={{ height: '30rem' }}>
                                    <div class="widget-header bordered d-flex align-items-center">
                                        <h1>ActivityBoard</h1>
                                    </div>
                                </div>
                            </div>
                            {/* <ul class="pull-right">
                                                      <li class="previous d-inline-block disabled">
                                                          <a href="#tab-3" aria-controls="tab-3"" class="btn btn-secondary ripple">Previous</a>
                                                      </li>
                                                      <li class="next d-inline-block">
                                                          <a href="#tab-2" aria-controls="tab-2" class="btn btn-gradient-01">Next</a>
                                                      </li>
                                                  </ul>
*/}
                        </div>
                        {/* End Col */}
                    </div>
                    {/* End Row */}
                </div>
                {/* End Container */}
                {/* Begin Large Modal */}
                <div id="modal-large" className="modal fade">
                    <div className="modal-dialog modal-lg">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h4 className="modal-title">Audit History</h4>
                                <button type="button" className="close" data-dismiss="modal">
                                    <span aria-hidden="true">×</span>
                                    <span className="sr-only">close</span>
                                </button>
                            </div>
                            <div className="modal-body">
                                <div className="widget-body no-padding">
                                    <ul className="ticket list-group w-100">
                                        {/* 01 */}
                                        <li className="list-group-item">
                                            <div className="media">
                                                <div className="media-left align-self-center pr-4">
                                                    <img src={require('../../assets/img/avatar/avatar-02.jpg')} className="user-img rounded-circle" alt="..." />
                                                </div>
                                                <div className="media-body align-self-center">
                                                    <div className="username">
                                                        <h4>Brandon Smith</h4>
                                                    </div>
                                                    <div className="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                      </p>
                                                    </div>
                                                    <div className="status"><span className="open mr-2">Open</span>(1 hour ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* End 01 */}
                                        {/* 02 */}
                                        <li className="list-group-item">
                                            <div className="media">
                                                <div className="media-left align-self-center pr-4">
                                                    <img src={require('../../assets/img/avatar/avatar-04.jpg')} className="user-img rounded-circle" alt="..." />
                                                </div>
                                                <div className="media-body align-self-center">
                                                    <div className="username">
                                                        <h4>Nathan Hunter</h4>
                                                    </div>
                                                    <div className="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                      </p>
                                                    </div>
                                                    <div className="status"><span className="pending mr-2">Modified</span>(2 hours ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* End 02 */}
                                        {/* 03 */}
                                        <li className="list-group-item">
                                            <div className="media">
                                                <div className="media-left align-self-center pr-4">
                                                    <img src={require('../../assets/img/avatar/avatar-05.jpg')} className="user-img rounded-circle" alt="..." />
                                                </div>
                                                <div className="media-body align-self-center">
                                                    <div className="username">
                                                        <h4>Megan Duncan</h4>
                                                    </div>
                                                    <div className="msg">
                                                        <p>
                                                            Hello, Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et mauris sapien sem, ornare id mauris vitae, ultricies volutpat ...
                      </p>
                                                    </div>
                                                    <div className="status"><span className="closed mr-2">Deleted</span>(1 day ago)</div>
                                                </div>
                                            </div>
                                        </li>
                                        {/* End 03 */}
                                    </ul>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-shadow" data-dismiss="modal">Close</button>
                                <button type="button" className="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
                {/* End Large Modal */}

                <a href="#" className="go-top"><i className="la la-arrow-up" /></a>
                {/* Offcanvas Sidebar */}
                {/* End Offcanvas Sidebar */}
                <Footer />
            </div >
        );
    }
}


export default ActivityBoard;