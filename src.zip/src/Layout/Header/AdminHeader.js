import React from 'react';
import { Link } from 'react-router-dom';

class AdminHeader extends React.Component {

    render() {

        return (
            <div className="page db-social chat">
                {/* Begin AdminHeader */}
                <header className="header">
                    <nav className="navbar fixed-top">
                        {/* Begin Search Box*/}
                        {/*     <div class="search-box">
                  <button class="dismiss"><i class="ion-close-round"></i></button>
                  <form id="searchForm" action="#" role="search">
                      <input type="search" placeholder="Search something ..." class="form-control">
                  </form>
              </div> */}
                        {/* End Search Box*/}
                        {/* Begin Topbar */}
                        <div className="navbar-holder d-flex align-items-center align-middle justify-content-between">
                            {/* Begin Logo */}
                            <div className="navbar-header">
                                {/* Toggle Button */}
                                <a id="toggle-btn" href="#" className="menu-btn active">
                                    <span />
                                    <span />
                                    <span />
                                </a>
                                {/* End Toggle */}
                                <a className="navbar-brand ml-3">
                                    <div className="brand-image brand-big">
                                        <img src={require('../../assets/img/logo.png')} alt="logo" style={{ width: 70 }} className="logo-big" />
                                    </div>
                                    <div className="brand-image brand-small">
                                        <img src={require('../../assets/img/logo.png')} alt="logo" className="logo-small" />
                                    </div>
                                </a>
                            </div>
                            {/* End Logo */}
                            {/* Begin Navbar Menu */}
                            <ul className="nav-menu list-unstyled d-flex flex-md-row align-items-md-center pull-right">
                                {/* Search */}
                                {/*   <li class="nav-item d-flex align-items-center"><a id="search" href="#"><i class="la la-search"></i></a></li> */}
                                {/* End Search */}
                                {/* Begin Notifications */}
                                <li className="nav-item dropdown"><a id="notifications" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" className="nav-link"><i className="la la-bell animated infinite swing" /><span className="badge-pulse" /></a>
                                    <ul aria-labelledby="notifications" className="dropdown-menu notification">
                                        <li>
                                            <div className="notifications-header">
                                                <div className="title">Notifications (2)</div>
                                                <div className="notifications-overlay" />
                                                <img src={require('../../assets/img/notifications/01.jpg')} alt="..." className="img-fluid" />
                                            </div>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div className="message-icon">
                                                    <i className="la la-user" />
                                                </div>
                                                <div className="message-body">
                                                    <div className="message-body-heading">
                                                        New message received
                                                            </div>
                                                    <span className="date"> 04/11/2019 </span>
                                                </div>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <div className="message-icon">
                                                    <i className="la la-calendar-check-o" />
                                                </div>
                                                <div className="message-body">
                                                    <div className="message-body-heading">
                                                        Abc Hospital Completed Onboarding
                                                    </div>
                                                    <span className="date"> 04/11/2019</span>
                                                </div>
                                            </a>
                                        </li>
                                        {/*  <li>
                                  <a rel="nofollow" href="#" class="dropdown-item all-notifications text-center">View All Notifications</a>
                              </li> */}
                                    </ul>
                                </li>
                                {/* End Notifications */}
                                {/* User */}
                                <li className="nav-item dropdown"><a id="user" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" className="nav-link"><img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." className="avatar rounded-circle" />
                                </a>
                                    <ul aria-labelledby="user" className="user-size dropdown-menu">
                                        <li className="welcome">
                                            <a href="#" className="edit-profil"><i className="la la-gear" /></a>
                                            <img src={require('../../assets/img/avatar/avatar-01.jpg')} alt="..." className="rounded-circle" />
                                        </li>
                                        <li>
                                            <a className="dropdown-item">
                                                Profile
                                             </a>
                                        </li>
                                        <li>
                                            <a className="dropdown-item">
                                                Support
                                                </a>
                                        </li>
                                        <li>
                                            <a className="dropdown-item">
                                                Logout
                                            </a>
                                        </li>
                                        <li className="separator" />
                                        {/* <li>
                                  <a href="pages-faq.html" class="dropdown-item no-padding-top"> 
                                      Faq
                                  </a>
                              </li> */}
                                        {/* <li><a rel="nofollow"  className="dropdown-item logout text-center"><i className="ti-power-off" /></a></li> */}
                                        <li>
                                            <Link to="/login" className="dropdown-item logout text-center"><i className="ti-power-off" /></Link>
                                        </li>
                                    </ul>
                                </li>
                                {/* End User */}
                                {/* Begin Quick Actions */}
                                {/*   <li class="nav-item"><a href="#off-canvas" class="open-sidebar"><i class="ti ti-comments"></i></a></li> */}
                                {/* End Quick Actions */}
                            </ul>
                            {/* End Navbar Menu */}
                        </div>
                        {/* End Topbar */}
                    </nav>
                </header>
                {/* End AdminHeader */}
                {/* Begin Page Content */}

            </div>

        );
    }
}


export default AdminHeader;