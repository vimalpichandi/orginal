import React from 'react';

class Footer extends React.Component {

  render() {

    return (
      // <div className="content-inner compact">
        <footer className="main-footer">
          <div className="row">
            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-start justify-content-lg-start justify-content-md-start justify-content-center">
              <a className="btn btn-gradient-01 text-white" href="#">Support Center</a>
            </div>
            <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 d-flex align-items-center justify-content-xl-end justify-content-lg-end justify-content-md-end justify-content-center">
              <ul className="nav">
                <li className="nav-item">
                  <a className="nav-link" href="www.solvedge.com">© 2019 SolvEdge Inc.</a>
                </li>
              </ul>
            </div>
          </div>
        </footer>
      // </div>

    );
  }
}


export default Footer;